/*
Author: 
Date: 

Description: 
*/
import java.util.Comparator;

public class Exercise20_21 {
  public static void main(String[] args) {
    GeometricObject[] list = {new Circle(5), new Rectangle(4, 5),
            new Circle(5.5), new Rectangle(2.4, 5), new Circle(0.5),
            new Rectangle(4, 65), new Circle(4.5), new Rectangle(4.4, 1),
            new Circle(6.5), new Rectangle(4, 5)};
    selectionSort(list, new GeometricObjectComparator());
    for (int i =0; i< list.length; i++) {
      System.out.println(list[i].getArea());
    }
  }

  //static int low=0;
  //static int high= list.length;
  public static <E> void selectionSort(E[] list, Comparator<? super E> comparator) {
    //if (low < high) {
    //int indexOfMin = low;
    //E min =  list[low].getArea();
    boolean run = true;
    for (int k = 1; k < list.length && run; k++) {
      for (int i = 0; i < list.length - k; i++) {
        if (comparator.compare(list[i], list[i + 1]) > 0) {
          E temp = list[i];
          list[i] = list[i + 1];
          list[i + 1] = temp;
        }
      }
      if (k == list.length - 1){
        run = false;
      }
    }
  }
}

