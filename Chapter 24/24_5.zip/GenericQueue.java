
public class GenericQueue<E> extends java.util.LinkedList<E> {
    public void enqueue(E e) {
        this.addLast(e);
    }

    public Object dequeue() {
        return removeFirst();
    }

    public int getSize() {
        return size();
    }

    @Override
    public String toString() {
        String str = "Queue: " + toString();
        return str;
    }
}