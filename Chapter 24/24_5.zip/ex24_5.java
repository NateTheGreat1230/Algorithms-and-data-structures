public class ex24_5 {
    public static void main(String[] args) {
        GenericQueue queue = new GenericQueue();
        queue.enqueue("testing");
        for(int i = 0; i < queue.size(); i++){
            System.out.println(queue.get(i).toString());
        }
        queue.enqueue("testing1");
        queue.enqueue("testing2");
        for(int i = 0; i < queue.size(); i++){
            System.out.println(queue.get(i).toString());
        }
        queue.dequeue();
        for(int i = 0; i < queue.size(); i++){
            System.out.println(queue.get(i).toString());
        }
    }
}
